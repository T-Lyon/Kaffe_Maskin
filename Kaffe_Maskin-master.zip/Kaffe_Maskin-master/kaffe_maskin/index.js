

class CoffeeMachine {

  constructor() {
    this.pluggedIn = false;
    this.connectedToWater = false;
    this.startMachine = false;
    this.selectBlackCoffee = false;
    this.selectCoffeeWithMilk = false;
    this.selectEspresso = false;
    this.pourCoffee = false;
    this.brewedCoffeeWithMilk = false;
    this.hasCapsule = false;
    this.brewedEspresso = false;
    this.insertedMoney = 0;
    this.amountOfCoffee = 0;
    this.coffeePerCup = 13;
  }

  

  plugIn() {
    this.pluggedIn = true;
  }

  connectToWater() {
    this.connectedToWater = true;
  }
  blackCoffee() {
    this.selectBlackCoffee = true;
  }
  coffeeWithMilk() {
    this.selectCoffeeWithMilk = true;
  }
  espresso() {
    this.selectEspresso = true;
  }
  pressStart() {
    if (this.insertedMoney >= this.pricePerCup) {
      return "here's your coffee";
    }
  }

  fillWithCoffee(amount) {
    
    this.amountOfCoffee += amount;
  }

  checkIfEnoughCoffeeForACup() {
    return this.amountOfCoffee >= this.coffeePerCup;
  }

  

  insertMoney(inserted) {
    
    if (typeof inserted !== 'number') {
      throw (new Error('You must insert money not ' + nonMoney));
    }
    this.insertedMoney += inserted;
  }

  insertCard(addedCard) {

    this.insertedMoney = addedCard;
  }

  addMilk() {
    this.hasMilk = true;
  }

  brewCoffeeWithMilk() {
    this.brewedCoffeeWithMilk = true;
  }

  capsuleCheck() {
    this.hasCapsule = true;
  }

  brewEspresso() {
    this.brewedEspresso = true;
  }

  dispenseCoffee() {
    this.pourCoffee = true;
  }
  checkIfEnoughCoffeeForACup() {
    return this.amountOfCoffee >= this.coffeePerCup;
  }

}


module.exports = CoffeeMachine;