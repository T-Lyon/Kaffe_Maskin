

class CoffeeMachine {

  constructor() {
    this.pluggedIn = false;
    this.connectedToWater = false;
    this.startMachine = false;
    this.selectedBlackCoffee = false;
    this.selectedCoffeeWithMilk = false;
    this.selectedEspresso = false;
    this.pourCoffee = false;
    this.brewedCoffeeWithMilk = false;
    this.hasCapsule = false;
    this.brewedEspresso = false;
    this.insertedMoney = 0;
    this.amountOfCoffee = 0;
    this.coffeePerCup = 13;
    this.priceForBlackCoffee = 10;
    this.priceForCoffeeWithMilk = 15;
    this.priceForEspresso = 20;
  }



  plugIn() {
    this.pluggedIn = true;
  }

  connectToWater() {
    this.connectedToWater = true;
  }
  pickedBlackCoffee() {
    this.selectedBlackCoffee = true;
  }
  pickedCoffeeWithMilk() {
    this.selectedCoffeeWithMilk = true;
  }
  pickedEspresso() {
    this.selectedEspresso = true;
  }
  pressStart(buttonName) {
    this.startMachine = true;
  }

  fillWithCoffee(amount) {

    this.amountOfCoffee += amount;
  }

  checkIfEnoughCoffeeForACup() {
    return this.amountOfCoffee >= this.coffeePerCup;
  }



  insertMoney(inserted) {

    if (typeof inserted !== 'number') {
      throw (new Error('You must insert money'));
    }
    this.insertedMoney += inserted;
  }

  addMilk() {
    this.hasMilk = true;
  }

  brewCoffeeWithMilk() {
    this.brewedCoffeeWithMilk = true;
  }

  capsuleCheck() {
    this.hasCapsule = true;
  }

  brewEspresso() {
    this.brewedEspresso = true;
  }

  dispenseCoffee(pourCoffee) {
    if (this.insertedMoney >= this.priceForBlackCoffee && this.startMachine == true || this.addedCard >= this.priceForBlackCoffee && this.startMachine == true) {
      this.pourCoffee = true;
      return this.pourCoffee
    }
    else if (this.insertedMoney >= this.priceForCoffeeWithMilk && this.startMachine == true || this.addedCard >= this.priceForCoffeeWithMilk && this.startMachine == true) {
      this.pourCoffee = true;
      return this.pourCoffee
    }
    else if (this.insertedMoney >= this.priceForEspresso && this.startMachine == true || this.addedCard >= this.priceForEspresso && this.startMachine == true) {
      this.pourCoffee = true;
      return this.pourCoffee
    }
    else {
      this.pourCoffee = true;
    }
  }
  checkIfEnoughCoffeeForACup() {
    return this.amountOfCoffee >= this.coffeePerCup;
  }

}


module.exports = CoffeeMachine;